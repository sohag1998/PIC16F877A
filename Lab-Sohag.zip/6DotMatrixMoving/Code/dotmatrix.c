#define col1 portb.f0
#define col2 portb.f1
#define col3 portb.f2
#define col4 portb.f3
#define col5 portb.f4
#define col6 portb.f5
#define col7 portb.f6
#define col8 portb.f7

#define display_row portd

unsigned char letter[8] = {0x3c,0x7e,0x66,0x7e,0x3e,0x06,0x7e,0x7c};
int i=0;
void main() {
     trisb = 0;
     trisd = 0;
     while(1)
     {
         display_row = letter[i+0];
         col1 = 1;
         delay_ms(1);
         col1 = 0;
         
         display_row = letter[i+1];
         col2 = 1;
         delay_ms(1);
         col2 = 0;
         
         display_row = letter[i+2];
         col3 = 1;
         delay_ms(1);
         col3 = 0;
         
                  
         display_row = letter[i+3];
         col4 = 1;
         delay_ms(1);
         col4 = 0;
         
         display_row = letter[i+4];
         col5 = 1;
         delay_ms(1);
         col5 = 0;
         
         display_row = letter[i+5];
         col6 = 1;
         delay_ms(1);
         col6 = 0;
         
         display_row = letter[i+6];
         col7 = 1;
         delay_ms(1);
         col7 = 0;
         
         display_row = letter[i+7];
         col8 = 1;
         delay_ms(1);
         col8 = 0;
     }
}