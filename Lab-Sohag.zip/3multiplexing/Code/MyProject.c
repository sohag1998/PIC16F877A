sbit DIS1 at PORTC.b0;
sbit DIS2 at PORTC.b1;
unsigned char CA[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
int i = 0, j, left_digit, right_digit;
void main() {
    TRISB = 0;
    TRISC.RC0 = 0;
    TRISC.RC1 = 0;
    DIS1 = 0;
    DIS2 = 0;

    while (1)
    {
          while(i <= 99)
          {
             left_digit = i / 10;
             right_digit = i % 10;

            for(j = 0; j < 10; j++)
            {
                DIS1 = 1;
                PORTB = CA[left_digit];
                delay_ms(10);
                DIS1 = 0;


                DIS2 = 1;
                PORTB = CA[right_digit];
                delay_ms(10);
                DIS2 = 0;

             }
             i++;
          }
          i -= 1;
          while(i >= 0)
          {
             left_digit = i / 10;
             right_digit = i % 10;

            for(j = 0; j < 10; j++)
            {
                DIS1 = 1;
                PORTB = CA[left_digit];
                delay_ms(10);
                DIS1 = 0;


                DIS2 = 1;
                PORTB = CA[right_digit];
                delay_ms(10);
                DIS2 = 0;

             }
             i--;
          }
          i += 1;
    }
    
}