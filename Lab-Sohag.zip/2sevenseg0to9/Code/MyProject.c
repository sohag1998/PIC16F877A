
unsigned char CA[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
int i = 0;
void main() {
    TRISB = 0;
    while(1){
        if(i > 9) i = 0;
        PORTB = CA[i];
        delay_ms(1000);
        i++;
    }

}