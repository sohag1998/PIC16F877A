void main() {
    TRISB.f0 = 0;
    TRISD.f0 = 1;
    
    portb.f0 = 0;
    portd.f0 = 0;
    
    while(1)
    {
        if(portd.f0 == 1)
        {
            portb.f0 = 1;
            delay_ms(2000);
            portb.f0 = 0;
        }
    }
}