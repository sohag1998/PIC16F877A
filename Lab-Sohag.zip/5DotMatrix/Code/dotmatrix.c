
#define col_1 portb.b0
#define col_2 portb.b1
#define col_3 portb.b2
#define col_4 portb.b3
#define col_5 portb.b4
#define output_d portd
int i = 0;

unsigned char digit[5] = {
                         0b0111110,
                         0b01000001,
                         0b01000001,
                         0b01000001,
                         0b0111110
                         };
void main() {

      trisb = 0;
      trisd = 0;
      col_1 = 0;
      col_2 = 0;
      col_3 = 0;
      col_4 = 0;
      col_5 = 0;
      
      output_d = 0;
      while(1){
          output_d = digit[i+0];
          col_1 = 1;
          delay_ms(1);
          col_1 = 0;
          
          output_d = digit[i+1];
          col_2 = 1;
          delay_ms(1);
          col_2 = 0;
          
          output_d = digit[i+2];
          col_3 = 1;
          delay_ms(1);
          col_3 = 0;
          
          output_d = digit[i+3];
          col_4 = 1;
          delay_ms(1);
          col_4 = 0;
          
          output_d = digit[i+4];
          col_5 = 1;
          delay_ms(1);
          col_5 = 0;
      }
}