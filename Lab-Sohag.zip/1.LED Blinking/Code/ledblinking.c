sbit LED at PORTB.B0;

void main() {
     TRISB.f0 = 0;
     while(1){
         LED = 1;
         delay_ms(200);
         LED = 0;
         delay_ms(200);
     }
}